package com.mycompany.jogador;
public class Dados {
    public static void main(String [] args){
        Jogador j1 = new Jogador();
        
        j1.setNome("Yuri");
        j1.setAltura(1.78f);
        j1.setIdade(22);
        j1.setPeso(87.7f);
        j1.setBid(1);
        
        j1.informacoes();
    }
}
