package com.mycompany.jogador;

public class Jogador {
    int bid;
    String nome;
    int numero;
    float altura;
    float peso;
    int idade;

    
    public int getBid(){
System.out.println("Identificador do Jogador");
return this.bid;
    }
    public void setBid(int b){
    this.bid = b;
    }

    public String getNome(){
System.out.println("Nome do Jogador:");
    return this.nome;
    }
    public String setNome(String n){   
    this.nome = n;
        return null;
    }
    
    public int getNumero(){
System.out.println("Numero do Jogador:");
return this.numero;
    }
    public int setNumero(int num){
        this.numero = num;
        return 0;
    }
    
    public float getAltura(){
System.out.println("Altura do Jogador:");
    return this.altura;
    }
    public float setAltura(float a){
        this.altura = a;
        return 0;
    }
    public float getPeso(){
System.out.println("Peso do Jogador");
return this.peso;
    }
    public float setPeso(float p){
        this.peso = p; 
        return 0;
    }
    public int getIdade(){
    return this.idade;
    }
    public void setIdade(int i){
     this.idade = i;   
    }
    public void informacoes(){
    System.out.println("Nome do Jogador: "+ this.getNome());
    System.out.println("Altura do Jogador: "+this.getAltura());
    System.out.println("Peso do Jogador: "+this.getPeso());
    }
}