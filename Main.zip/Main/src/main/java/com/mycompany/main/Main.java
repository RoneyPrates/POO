package com.mycompany.main;
/**
 *
 * @author roney
 */
public class Main{
    public static void main(String[] args) {
        
        Animal animal = new Cachorro();       
        animal.fazerBarulho();
        animal.mover();
        
        animal = new Gato();
        animal.fazerBarulho();
        animal.mover();
        
    }
}