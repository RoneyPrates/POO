package com.mycompany.main;

/**
 *
 * @author roney
 */
public class Animal {
    public void fazerBarulho(){
        System.out.println("O animal está fazendo barulho");
    }
    public void mover(){
}
}

class Cachorro extends Animal{
@Override
public void fazerBarulho(){
        System.out.println("O cachorro latiu");
}
}
class Gato extends Animal {
@Override
public void fazerBarulho(){
        System.out.println("O gato miou");
}
}