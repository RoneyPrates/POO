package com.mycompany.animal;

/**
 *
 * @author roney
 */
public class Animal {
    public void emitirSom(){
    }
    public void mover(){
}
}

class Cachorro extends Animal{
@Override
public void emitirSom(){
        System.out.println("O cachorro latiu");
}
@Override
public void mover(){
        System.out.println("O cachorro se moveu");
}
}
class Gato extends Animal {
@Override
public void emitirSom(){
        System.out.println("O gato miou");
}
@Override
public void mover(){
        System.out.println("O gato se moveu");
}
}

