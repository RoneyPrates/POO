package com.mycompany.testarcalculadora;



public class TestarCalculadora {
    public static void main(String[] args) {
        Calculadora calculo = new Calculadora();

        int somaInteiros = calculo.somar(5, 1);
        System.out.println("A soma dos inteiros é: " + somaInteiros);

        double somaPontoFlutuante = calculo.somar(5.9, 3.2);
        System.out.println("A soma dos pontos flutuantes é: " + somaPontoFlutuante);

        // Teste do método somar(int[] numeros)
        int[] numeros = { 1, 2, 3, 4, 5 };
        int somaArray = calculo.somar(numeros);
        System.out.println("A soma dos números do array é: " + somaArray);
    }
}